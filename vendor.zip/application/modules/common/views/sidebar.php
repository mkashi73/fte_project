        <div class="slim-body">
          <div class="slim-sidebar">
            <label class="sidebar-label">Navigation</label>
            <ul class="nav nav-sidebar">
              <?= $links['show_menu']; ?>
            </ul>
          </div><!-- slim-sidebar -->