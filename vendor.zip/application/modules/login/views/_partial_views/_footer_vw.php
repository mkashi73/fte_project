	<!-- base url -->
    <script type="text/javascript"> let base_url = "<?= base_url(); ?>"; </script>
    <!-- jquery js -->
	<script src="<?= base_url(); ?>assets/lib/jquery/js/jquery.js"></script>
	<!-- popper js -->
    <script src="<?= base_url(); ?>assets/lib/popper.js/js/popper.js"></script>
    <!-- bootstrap js -->
    <script src="<?= base_url(); ?>assets/lib/bootstrap/js/bootstrap.js"></script>
    <!-- slim js -->
    <script src="<?= base_url(); ?>assets/js/slim.js"></script>
    <!-- login js -->
    <script src="<?= base_url(); ?>assets/template/pages/login/js/login.js"></script>
  </body>
</html>