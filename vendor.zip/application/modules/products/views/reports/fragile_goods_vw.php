<div style='padding-left: 70px; padding-right: 70px; width: 600px;'><br />
	<h3 style="text-align: center">Fast Track Express</h3><br />
	<h4 style="text-align: center; ">Undertaking for Fragile Goods</h4><br /><br />
	
	<span>We, M/s Fast Track Express (Pvt) Limited. Hereby shall not be held responsible, in either way, for partial or complete damae, during the storage, handling, transportation ad forwarding of the following material/goods.</span><br /><br />
	<span style="padding-left: 40px;">1. Unfired Clay Items</span><br />
	<span style="padding-left: 40px;">2. Crockery Items</span><br />
	<span style="padding-left: 40px;">3.Stoneware Items</span><br />
	<span style="padding-left: 40px;">4. Porcelain items</span><br />
	<span style="padding-left: 40px;">5. All other items declated brittle/breakable by Fast Track Express</span><br /><br />
	<span>The shipper has given his/her signatures below for consent against the above statement and the CN/Invoice# <strong><?= $productRecord['CN_NUMBER'] ?></strong> <label id="lblCNNo"></label> dated <strong><label id="lblCurrentDate"> <?= $productDate ?></label></strong> has been issued upon his/her reequest accordingly, Moreover, he/she has agreed to cease his/her rights claims and limitations, whatsoever, againt M/s. Fast Track Express (pvt) Limited, in case of partial or complete damage of good, mentioned in the aforementioned CN/Invoice.</span>
	<br /><br />
	<br /><br />
	<h4>
		Shipper:
	</h3>
	<br />
	<br />
	<span>
		Name:
	</span>
	<br />
	<br />
	<span>
		CNIC No:
	</span>
	<br />
	<br />
	<span>
		Dated:
	</span>
	<br />
	<br />

	<span>
		Cell No:
	</span>
	<br />
	<br />
	<br />
	<br />
	
	<span>Shipper Signature and Thumb Expressions</span><br />
	
</div>