<div style='padding-left: 70px; padding-right: 70px; width: 600px;'><br />
	<h3 style="text-align: center">Fast Track Express</h3><br />

	<h2 style="text-align: center; ">Undertaking</h2><br /><br />
	
	<h4 style="text-align: center;">TO WHOM IT MAY CONCERN!</h4><br />
	
	<span>We hereby declare that there is no Narcoticss, Anti-drugs and IATA restricted items in this shipmment, if found such items at any stage we shall be responsible entirely what so ever.</span><br /><br /><br />
	
	<span>Total Packages</span>
	<br />
	<br />
	
	<span style="font-weight: bold;">AWB No:</span>
	<label id="lblCNNumber">
		<?= $productRecord['CN_NUMBER'] ?>
	</label>
	<br />
	<br />
	<span style="font-weight: bold;">
	Dated: 
		<?= $productRecord['E_DATE_TIME'] ?>
	</span>
	<label id="lblDated">
		
	</label>
	<br />
	<br />
	<br />
	<br />
	<span>Regards</span>
	<br />
	<br />
	<span>
		Name: 
	</span>
	<br />
	<br />
	<br />
	<span>
		CNIC No: 
	</span>
	<br />
	<br />
	<br />
	<span>
		Cell No: 
	</span>
	<br />
	<br />
	<br />
	<br />
	
	<span>Shipper Signature and Thumb Expressions</span><br />
	
	
</div>